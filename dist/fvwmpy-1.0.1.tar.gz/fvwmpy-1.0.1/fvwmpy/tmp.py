def resync(buf):
    found = False
    while not found:
        peek = buf.peek()
        position=peek.find(b'abcd')
        if position == -1:
            self._fromfvwm.read(len(peek))
        else:
            self._fromfvwm.read(position)
            found = True
            
class dd(dict):
    def __getattr__(self,attr):
        return self[attr]

    
    
